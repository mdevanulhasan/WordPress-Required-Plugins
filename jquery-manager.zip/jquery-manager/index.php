<?php // Silence is golden, some servers are configured to show all the folders if there is no index file aka directory listings. This is to prevent that, security through obscurity.
