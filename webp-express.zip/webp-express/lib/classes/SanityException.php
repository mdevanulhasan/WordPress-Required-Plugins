<?php

namespace WebPExpress;

class SanityException extends \Exception
{
}
