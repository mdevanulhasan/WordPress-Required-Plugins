=== WP Anything Downloader ===
Contributors: d3logics, vinit-sharma, devshubham715
Donate link: https://d3logics.com
Tags:  Theme downloader. Plugin downloader, wordpress theme and plugin download, direct download
Requires at least: 3.3
Tested up to: 5.3.2
Stable tag: 3.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


WP Anything Downloader


== Description ==

This plugin allows you to Direct download Any theme and plugin from wp admin panel. best plugin for download theme or plugin from wp-admin

Perfect plugin  for direct download theme and plugin  with admin panel.

== Installation ==

== Frequently Asked Questions ==

Ques : Is this Plugin Download themes

Ans  : Yes

Ques : Is this Plugin Download plugins

Ans  : Yes


== Screenshots ==
1. Theme Download button
2. Plugin Download plugin


== Upgrade Notice ==

== Changelog ==
== 3.0.1 ==

*  Fixed a bug 

== Changelog ==
== 3.0.0 ==

*  Fixed a bug 

== 2.0.1 ==

* Security Updates

== 2.0.0 ==

* Fixed a bug 

== 1.0.0 ==

* Display WP Anything Downloader
