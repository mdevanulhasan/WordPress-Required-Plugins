<?php
/**
 * @package TutorLMS/Templates
 * @version 1.7.4
 */

?>

<p><?php _e('Dear {instructor_username},', 'tutor-pro'); ?></p>

<p>
	<?php _e('Your withdrawal request has been approved. Please check the transaction notification on your connected withdrawal method.', 'tutor-pro'); ?>
</p>