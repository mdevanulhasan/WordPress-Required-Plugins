<?php
/**
 * @package TutorLMS/Templates
 * @version 1.7.4
 */

?>

<p><?php _e('Dear {instructor_username},', 'tutor-pro'); ?> </p>

<p>
	<?php _e('Unfortunately, your withdrawal request has been rejected. Please contact the site admins directly for further information.', 'tutor-pro'); ?>
</p>