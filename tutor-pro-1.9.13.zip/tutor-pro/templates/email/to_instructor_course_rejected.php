<?php
/**
 * @package TutorLMS/Templates
 * @version 1.9.8
 */

?>

<p><?php _e('Dear {instructor_name},', 'tutor-pro'); ?></p>
<p>
    <?php _e('Sorry to let you know that your submitted course could not be published  on <strong>{site_name}</strong>', 'tutor-pro'); ?>
</p>
