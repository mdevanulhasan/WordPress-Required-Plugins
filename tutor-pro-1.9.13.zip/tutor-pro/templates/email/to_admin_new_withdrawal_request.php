<?php
/**
 * @package TutorLMS/Templates
 * @version 1.7.4
 */

?>

<p>
    <?php _e('{instructor_username}  has submitted a new withdrawal request.', 'tutor-pro'); ?>
</p>