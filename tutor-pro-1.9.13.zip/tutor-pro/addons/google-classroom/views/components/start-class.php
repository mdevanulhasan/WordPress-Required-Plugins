<br/>
<div class="tutor-course-compelte-form-wrap">
    <a class="tutor-button tutor-button-primary" href="<?php echo $classroom_url; ?>">
        <?php echo __( 'Start Course', 'tutor-pro'); ?>
    </a>
</div>