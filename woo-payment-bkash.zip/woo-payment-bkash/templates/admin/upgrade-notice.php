<?php
/**
 * Upgrade notice.
 *
 * @package DC-Bkash
 */

?>

<div class="wrap">
	<div class="wp-clearfix notice notice-info dc-bkash-notice-info">
		<div id="dc-bkash-upgrade-notice-container"></div>
	</div>
</div>
