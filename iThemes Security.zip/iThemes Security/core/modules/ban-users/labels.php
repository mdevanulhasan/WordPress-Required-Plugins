<?php

return [
	'title' => __( 'Ban Users', 'better-wp-security' ),
];
