<?php

return [
	'title' => __( 'Core', 'better-wp-security' ),
];
