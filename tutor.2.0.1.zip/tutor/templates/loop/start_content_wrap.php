<?php
/**
 * @package TutorLMS/Templates
 * @version 1.4.3
 */
?>

<div class="tutor-course-listing-item-body tutor-px-20 tutor-py-20">