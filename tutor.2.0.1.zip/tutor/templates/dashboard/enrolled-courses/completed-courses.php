<?php
    /**
     * @package TutorLMS/Templates
     * @version 1.4.3
     */

    $active_tab = 'enrolled-courses/completed-courses';
    include dirname(__DIR__) . DIRECTORY_SEPARATOR . 'enrolled-courses.php';
?>
