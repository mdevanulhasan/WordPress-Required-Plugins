<?php
/**
 * @package TutorLMS/Templates
 * @version 1.4.3
 */

?>
<input type="text" name="withdraw_method_field[<?php echo esc_attr( $method_id ); ?>][<?php echo esc_attr( $field_name ); ?>]" value="<?php echo esc_attr( $old_value ); ?>" >
