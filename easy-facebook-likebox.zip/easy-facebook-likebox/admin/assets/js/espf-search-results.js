jQuery('.espf-search-hide-btn').on('click', function($) {

  jQuery('.plugin-card-easy-facebook-likebox-search').slideUp().remove();

});