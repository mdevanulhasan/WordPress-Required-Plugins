<?php

do_action( 'efbl_before_feed_footer', $efbl_queried_data );