<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
	function duplicator_header($title)
	{
		echo "<h1>".esc_html($title)."</h1>";
	}
?>