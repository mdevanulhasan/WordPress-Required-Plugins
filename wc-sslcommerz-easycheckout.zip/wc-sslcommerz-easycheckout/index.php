<?php
	# Welcome to SSLCommerz. This is SSLCommerz official plugin.
?>