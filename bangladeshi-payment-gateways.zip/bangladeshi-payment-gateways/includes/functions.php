<?php
/**
 * Functions here.
 *
 * @package BDPaymentGateways
 */
